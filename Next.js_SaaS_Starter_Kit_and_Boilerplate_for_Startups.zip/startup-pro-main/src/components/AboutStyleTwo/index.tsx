import SectionOne from "./SectionOne";
import SectionTwo from "./SectionTwo";

const AboutStyleTwo = () => {
  return (
    <>
      <SectionOne />
      <SectionTwo />
    </>
  );
};

export default AboutStyleTwo;
