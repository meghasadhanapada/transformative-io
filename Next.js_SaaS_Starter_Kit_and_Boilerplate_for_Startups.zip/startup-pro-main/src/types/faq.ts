export type Faq = {
  id: number;
  ques: string;
  ans: string;
};
