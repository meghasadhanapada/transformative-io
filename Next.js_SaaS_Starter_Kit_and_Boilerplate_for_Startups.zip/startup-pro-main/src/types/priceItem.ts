export type Price = {
  id: string;
  nickname: string;
  unit_amount: number;
};
