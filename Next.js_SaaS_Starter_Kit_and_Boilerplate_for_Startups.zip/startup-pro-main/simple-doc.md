// clone the code

// run `npm install`

set up the env variables for stripe payment, next-auth provider.

// then `npm run dev`

## All env are there

GOOGLE_CLIENT_ID="300592664248-702riln7vbipf5ads77cdt6bk4758unp.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET="GOCSPX-Qe7EQliw8rjSTl9kAlv3iEtUwKA\*"

GITHUB_CLIENT_ID=7c35e1bb8af11e610198
GITHUB_CLIENT_SECRET=ffa115acdba6b59880d9b41ff6731c57f0bcd53b

STRIPE_SECRET_KEY=sk_test_51NQiwSLtGdPVhGLeYnr9G5KymeAZuxHfUQVZobqSAi8cKpD1NjUQGcf0hON96QIs8IwJYMEnttfVZSotOzd8VvPr00Yiw2IvX1

SECRET = 'secret'
DATABASE_URL="postgres://postgres:5e0ajjBv7x7TMOCm5KZTi7Sq5k7HbwKpAXjNjA7DK73UT2nStORfWdp5tgs6jLgS@49.13.163.192:5432/postgres"

NEXT_PUBLIC_SANITY_PROJECT_ID="twjhlmkd"
NEXT_PUBLIC_SANITY_PROJECT_TITLE="Startup Pro"
SANITY_HOOK_SECRET="sanity_secret"
SANITY_API_KEY="skKaH3rSWudlffsHrphDb3pWZCjQTCx2FBOv501yb10KZ40hDizYRML1poBPvG1pL9HKGP11cheGGqGrRyacbO2f1OKfTRX5HJf5gqg07fcPnAWfbyyOKDMA00JJteAj22wDMEZcMVrf1As8CGHVgM3ho7q9CDEEVVxGWWgJloDBaaeZaPjt"

SITE_URL="http://localhost:3000"
SITE_NAME="Startup Pro"
AUTHOR_NAME="Startup Pro"
